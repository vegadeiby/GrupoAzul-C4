package com.unab.grupo12.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.unab.grupo12.Entity.Usuario;
import com.unab.grupo12.Repository.IUsuarioRepository;

@Service
public class UsuarioService implements IUsuarioService{
	
	@Autowired
	private IUsuarioRepository repository;
	
	@Override
	public List<Usuario> all() {
		return this.repository.findAll();
	}
	
	@Override
	public Optional<Usuario> findById(Long id) {
		return this.repository.findById(id);
	}
	
	@Override
	public Usuario save(Usuario usuario) {
		return this.repository.save(usuario);
	}
	
	@Override
	public void delete(Long id) {
		this.repository.deleteById(id);
	}
}
