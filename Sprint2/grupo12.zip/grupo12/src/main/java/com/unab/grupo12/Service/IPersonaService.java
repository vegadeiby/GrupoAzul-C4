package com.unab.grupo12.Service;

import java.util.List;
import java.util.Optional;

import com.unab.grupo12.Entity.Persona;

public interface IPersonaService {

	public List<Persona> all();
	
	public Optional<Persona> findById(Long id);
	
	public Persona save(Persona persona);
	
	public void delete(Long id);
}
