package com.unab.grupo12.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.unab.grupo12.Entity.Persona;

public interface IPersonaRepository extends JpaRepository<Persona, Long>{

}
