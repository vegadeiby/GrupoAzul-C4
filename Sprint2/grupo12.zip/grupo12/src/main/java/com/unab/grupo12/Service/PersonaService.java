package com.unab.grupo12.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.unab.grupo12.Entity.Persona;
import com.unab.grupo12.Repository.IPersonaRepository;

@Service
public class PersonaService implements IPersonaService{

	@Autowired
	private IPersonaRepository repository;
	
	@Override
	public List<Persona> all() {
		return this.repository.findAll();
	}
	
	@Override
	public Optional<Persona> findById(Long id) {
		return this.repository.findById(id);
	}
	
	@Override
	public Persona save(Persona persona) {
		return this.repository.save(persona);
	}
	
	@Override
	public void delete(Long id) {
		this.repository.deleteById(id);
	}
	
}
